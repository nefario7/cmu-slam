# Necessary: pip install -r requirements will build then install, so if numpy is not existing the procedure will fail.
pip install numpy
pip install cffi
pip install scipy
pip install matplotlib
pip install git+https://github.com/theNded/PySPQR.git
